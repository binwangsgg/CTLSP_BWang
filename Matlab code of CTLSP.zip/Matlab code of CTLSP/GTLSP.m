function [xyz3_2,n0]=GTLSP(xyzt1,xyz2,Dt1,D2,sigma00,eps)%%%% Developed by Bin Wang from Nanjing Tech University

%%%%% xyzt1: coordinate vector observed in the source system, including the vector for common and non-common points
%%%%% xyz2:  coordinate vector of the common points observed in the target system
%%%%% Dt1:  variance-covariance matrix of xyzt1;
%%%%% D2:  variance-covariance matrix of xyz2;
%%%%% sigma00:  The square root of the priori variance factor
%%%%% eps:  The threshold value to stop the iteration

%%%%% xyz3_2:  Transformed coordinates of non-common points obtained by GTLSP
%%%%% n0:  number of iterations

k=size(xyzt1,1)/3;
k1=size(xyz2,1)/3;
k2=k-k1;

xt1=zeros(k,1); yt1=zeros(k,1); zt1=zeros(k,1);
x2=zeros(k1,1); y2=zeros(k1,1); z2=zeros(k1,1);

for i=1:k
    xt1(i)=xyzt1(3*i-2);
    yt1(i)=xyzt1(3*i-1);
    zt1(i)=xyzt1(3*i);
end

x1=xt1(1:k1);y1=yt1(1:k1);z1=zt1(1:k1);%%%% The coordinates of the common pints in source system
x3=xt1(k1+1:k);y3=yt1(k1+1:k);z3=zt1(k1+1:k);%%%%% The coordinates of the non-common pints in source system

for i=1:k1
    x2(i)=xyz2(3*i-2);
    y2(i)=xyz2(3*i-1);
    z2(i)=xyz2(3*i);
end

x11=zeros(k1,1);y11=zeros(k1,1);z11=zeros(k1,1);
x21=zeros(k1,1);y21=zeros(k1,1);z21=zeros(k1,1);
x31=zeros(k2,1);y31=zeros(k2,1);z31=zeros(k2,1);


%%%Centralize the source coordinates
sumx1=0;sumy1=0;sumz1=0;
for i=1:k1
   sumx1=sumx1+x1(i);
   sumy1=sumy1+y1(i);
   sumz1=sumz1+z1(i);
end
x1g=sumx1/k1;
y1g=sumy1/k1;
z1g=sumz1/k1;

for i=1:k1
    x11(i)=x1(i)-x1g;
    y11(i)=y1(i)-y1g;
    z11(i)=z1(i)-z1g;   
end

% % for i=1:(k-k1)
% %     x31(i)=x3(i)-x1g;
% %     y31(i)=y3(i)-y1g;
% %     z31(i)=z3(i)-z1g;   
% % end


%%%Centralize the target coordinates
sumx2=0;sumy2=0;sumz2=0;
for i=1:k1
   sumx2=sumx2+x2(i);
   sumy2=sumy2+y2(i);
   sumz2=sumz2+z2(i);
end
x2g=sumx2/k1;
y2g=sumy2/k1;
z2g=sumz2/k1;
L=zeros(3*k1,1);
for i=1:k1
    x21(i)=x2(i)-x2g;
    y21(i)=y2(i)-y2g;
    z21(i)=z2(i)-z2g;   
    L(3*i-2)=x21(i);
    L(3*i-1)=y21(i);
    L(3*i)=z21(i);
end



%%%%% Obtain the cofact matrix
Qt1=Dt1/(sigma00^2);
Q2=D2/(sigma00^2);

Q1=Qt1(1:3*k1,1:3*k1); %%%%%% The cofact matrix for the coordinates of common points in source system
Q31=Qt1(3*k1+1:3*k,1:3*k1); %%%%% The cofact matrix for the coordinates between common and non-common points in source system



%%% Set the initial values of the transformation parameters
dalta_x0=0;dalta_y0=0;dalta_z0=0;
K0=1;alpha0=0;beta0=0;gamma0=0;


%%%% Set the initial value for the error vector of source coordinates of common points
e1=zeros(3*k1,1);

%%%% Set the initial values of the related matrices displayed in section 4 of the paper
A0=zeros(3*k1,7);
B0=zeros(3*k1,3*k1);
Fi0=zeros(3*k1,1);

n0=0; 

%%% iteration procedure
while 1 
 n0=n0+1;
 


M1=[1 0 0;
    0 cos(alpha0) sin(alpha0);
    0 -sin(alpha0) cos(alpha0)];
M2=[cos(beta0) 0 -sin(beta0);
    0 1 0;
    sin(beta0) 0 cos(beta0)];
M3=[cos(gamma0) sin(gamma0) 0;
    -sin(gamma0) cos(gamma0) 0;
    0 0 1];



M=M3*M2*M1;


PdM1=M3*M2*[0 0 0;0 -sin(alpha0) cos(alpha0);0 -cos(alpha0) -sin(alpha0)];
PdM2=M3*[-sin(beta0) 0 -cos(beta0);0 0 0;cos(beta0) 0 -sin(beta0)]*M1;
PdM3=[-sin(gamma0) cos(gamma0) 0;-cos(gamma0) -sin(gamma0) 0;0 0 0]*M2*M1;



for i=1:k1
  temp1=[x11(i);y11(i);z11(i)];
  temp2=temp1-e1(3*i-2:3*i);
  temp3=[M*temp2 K0*PdM1*temp2 K0*PdM2*temp2 K0*PdM3*temp2];
  A0(3*i-2:3*i,:)=[eye(3) temp3];  
  B0(3*i-2:3*i,3*i-2:3*i)=-K0*M;
  Fi0(3*i-2:3*i)=K0*M*temp2+[dalta_x0;dalta_y0;dalta_z0];
end


temp1=Q1*B0';

QC0=Q2+B0*temp1;
PC0=inv(QC0);

dertakX=inv(A0'*PC0*A0)*A0'*PC0*(L-Fi0+B0*e1); %%% The correction vector of the parameters
lamda=PC0*(L-Fi0+B0*e1-A0*dertakX);

e1=temp1*lamda;


dalta_x0=dalta_x0+dertakX(1);
dalta_y0=dalta_y0+dertakX(2);
dalta_z0=dalta_z0+dertakX(3);
K0=K0+dertakX(4);
alpha0=alpha0+dertakX(5);
beta0=beta0+dertakX(6);
gamma0=gamma0+dertakX(7);

%%%% %%%convert the rotation angles into the range between -pi to pi
alpha0=angle01(alpha0);
beta0=angle01(beta0);
gamma0=angle01(gamma0);


if K0<0  %%%%% if the the scale ratio becomes nonpositive, reset it to 1
    K0=1;
end


if norm(dertakX)<eps
% % if max(abs(dertakX))<1e-8
    break;
end

end



V=L-Fi0+B0*e1-A0*dertakX; 

sigma0=sqrt(V'*PC0*V/(size(A0,1)-7)); %%%% The square root of the posterior variance factor

% % e3=Q31*B0'*PC0*(L-Fi0+B0*e1-A0*dertakX); 
e3=Q31*B0'*lamda; %%%% estimated error vector for the source coordinates of non-common points

M1=[1 0 0;
    0 cos(alpha0) sin(alpha0);
    0 -sin(alpha0) cos(alpha0)];
M2=[cos(beta0) 0 -sin(beta0);
    0 1 0;
    sin(beta0) 0 cos(beta0)];
M3=[cos(gamma0) sin(gamma0) 0;
    -sin(gamma0) cos(gamma0) 0;
    0 0 1];

M=M3*M2*M1;

derta_xyz0=[dalta_x0;dalta_y0;dalta_z0]+[x2g;y2g;z2g]-K0*M*[x1g;y1g;z1g]; %%% Obtain the translation parameters from decentralized source to target system
dalta_x0=derta_xyz0(1);
dalta_y0=derta_xyz0(2);
dalta_z0=derta_xyz0(3);

xyz3_2=zeros(3*k2,1);


for i=1:k2
    temp1=[x3(i);y3(i);z3(i)];
    temp2=temp1-e3(3*i-2:3*i);
    xyz3_2(3*i-2:3*i)=K0*M*temp2+[dalta_x0;dalta_y0;dalta_z0];
    
       
end