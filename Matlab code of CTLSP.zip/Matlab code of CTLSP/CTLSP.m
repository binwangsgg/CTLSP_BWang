function [xyz3_2,n0]=CTLSP(xyzt1,xyz2,Dt1,D2,sigma00,eps)%%%% Developed by Bin Wang from Nanjing Tech University

%%%%% xyzt1: coordinate vector observed in the source system, including the vector for common and non-common points
%%%%% xyz2:  coordinate vector of the common points observed in the target system
%%%%% Dt1:  variance-covariance matrix of xyzt1;
%%%%% D2:  variance-covariance matrix of xyz2;
%%%%% sigma00:  The square root of the priori variance factor
%%%%% eps:  The threshold value to stop the iteration

%%%%% xyz3_2:  Transformed coordinates of non-common points obtained by CTLSP
%%%%% n0:  number of iterations


k=size(xyzt1,1)/3;
k1=size(xyz2,1)/3;
k2=k-k1;

xt1=zeros(k,1); yt1=zeros(k,1); zt1=zeros(k,1);
x2=zeros(k1,1); y2=zeros(k1,1); z2=zeros(k1,1);

for i=1:k
    xt1(i)=xyzt1(3*i-2);
    yt1(i)=xyzt1(3*i-1);
    zt1(i)=xyzt1(3*i);
end

x1=xt1(1:k1);y1=yt1(1:k1);z1=zt1(1:k1);%%%% The coordinates of the common pints in source system
x3=xt1(k1+1:k);y3=yt1(k1+1:k);z3=zt1(k1+1:k);%%%%% The coordinates of the non-common pints in source system

for i=1:k1
    x2(i)=xyz2(3*i-2);
    y2(i)=xyz2(3*i-1);
    z2(i)=xyz2(3*i);
end

x11=zeros(k1,1);y11=zeros(k1,1);z11=zeros(k1,1);
x21=zeros(k1,1);y21=zeros(k1,1);z21=zeros(k1,1);
x31=zeros(k2,1);y31=zeros(k2,1);z31=zeros(k2,1);


%%%Centralize the source coordinates
sumx1=0;sumy1=0;sumz1=0;
for i=1:k1
   sumx1=sumx1+x1(i);
   sumy1=sumy1+y1(i);
   sumz1=sumz1+z1(i);
end
x1g=sumx1/k1;
y1g=sumy1/k1;
z1g=sumz1/k1;



for i=1:k1
    x11(i)=x1(i)-x1g;
    y11(i)=y1(i)-y1g;
    z11(i)=z1(i)-z1g;   
end



%%%Centralize the target coordinates
sumx2=0;sumy2=0;sumz2=0;
for i=1:k1
   sumx2=sumx2+x2(i);
   sumy2=sumy2+y2(i);
   sumz2=sumz2+z2(i);
end
x2g=sumx2/k1;
y2g=sumy2/k1;
z2g=sumz2/k1;
L=zeros(3*k1,1);
for i=1:k1
    x21(i)=x2(i)-x2g;
    y21(i)=y2(i)-y2g;
    z21(i)=z2(i)-z2g;   
    L(3*i-2)=x21(i);
    L(3*i-1)=y21(i);
    L(3*i)=z21(i);
end



%%%%% Obtain the cofact matrix
Qt1=Dt1/(sigma00^2);
Q2=D2/(sigma00^2);

Q1=Qt1(1:3*k1,1:3*k1); %%%%%% The cofact matrix for the coordinates of common points in source system
Q31=Qt1(3*k1+1:3*k,1:3*k1); %%%%% The cofact matrix for the coordinates between common and non-common points in source system



A1=zeros(3*k1,12);%%%% coefficient matrix

for i=1:k1
    d1=x11(i);
    d2=y11(i);
    d3=z11(i);
    A1(3*i-2,1)=1;
    A1(3*i-2,4)=d1;
    A1(3*i-2,5)=d2;
    A1(3*i-2,6)=d3;
    A1(3*i-1,2)=1;
    A1(3*i-1,7)=d1;
    A1(3*i-1,8)=d2;
    A1(3*i-1,9)=d3;
    A1(3*i,3)=1;
    A1(3*i,10)=d1;
    A1(3*i,11)=d2;
    A1(3*i,12)=d3;
end
kx0=inv(A1'*A1)*A1'*L;% % % %%% Calculate the initial values of the transformation parameters using linear LS.
kx_ls=kx0;



%%%% Set the initial value for the error vector of source coordinates of common points
e1=zeros(3*k1,1);


C1=zeros(5,3);
W=zeros(5,1);
n0=0; 

A10=zeros(3*k1,12);
%%% iteration procedure
while 1 
 n0=n0+1;
 kx11=kx0(4);kx12=kx0(5);kx13=kx0(6);
kx21=kx0(7);kx22=kx0(8);kx23=kx0(9);
kx31=kx0(10);kx32=kx0(11);kx33=kx0(12);

% % % Paramat=[kx11 kx12 kx13;kx21 kx22 kx23;kx31 kx32 kx33]; 

C2=[2*kx11 2*kx12 2*kx13 0 0 0 -2*kx31 -2*kx32 -2*kx33;
    0 0 0 2*kx21 2*kx22 2*kx23 -2*kx31 -2*kx32 -2*kx33;
    kx21 kx22 kx23 kx11 kx12 kx13 0 0 0;
    kx31 kx32 kx33 0 0 0 kx11 kx12 kx13;
    0 0 0 kx31 kx32 kx33 kx21 kx22 kx23];
  C=[C1 C2];
  
  W(1)=kx11^2+kx12^2+kx13^2-kx31^2-kx32^2-kx33^2;
  W(2)=kx21^2+kx22^2+kx23^2-kx31^2-kx32^2-kx33^2;
  W(3)=kx11*kx21+kx12*kx22+kx13*kx23;
  W(4)=kx11*kx31+kx12*kx32+kx13*kx33;
  W(5)=kx31*kx21+kx32*kx22+kx33*kx23;
  
 


for i=1:k1
    d1=x11(i)-e1(3*i-2);
    d2=y11(i)-e1(3*i-1);
    d3=z11(i)-e1(3*i);
    A10(3*i-2,1)=1;
    A10(3*i-2,4)=d1;
    A10(3*i-2,5)=d2;
    A10(3*i-2,6)=d3;
    A10(3*i-1,2)=1;
    A10(3*i-1,7)=d1;
    A10(3*i-1,8)=d2;
    A10(3*i-1,9)=d3;
    A10(3*i,3)=1;
    A10(3*i,10)=d1;
    A10(3*i,11)=d2;
    A10(3*i,12)=d3;
end




% % temp1=B1'*kron(kx0,Im);
temp1=zeros(3*k1,3*k1);
for i=1:k1
    temp1(3*i-2,3*i-2)=kx0(4);
    temp1(3*i-2,3*i-1)=kx0(5);
    temp1(3*i-2,3*i)=kx0(6);
    temp1(3*i-1,3*i-2)=kx0(7);
    temp1(3*i-1,3*i-1)=kx0(8);
    temp1(3*i-1,3*i)=kx0(9);
    temp1(3*i,3*i-2)=kx0(10);
    temp1(3*i,3*i-1)=kx0(11);
    temp1(3*i,3*i)=kx0(12);
end


Ql0=Q2+temp1*Q1*temp1';

Pl0=inv(Ql0);

N1=A10'*Pl0*A10;
iN1=inv(N1);
N2=C*iN1*C';
iN2=inv(N2);
dertakx=(iN1-iN1*C'*iN2*C*iN1)*A10'*Pl0*(L-A1*kx0)-iN1*C'*iN2*W;
lamda=Pl0*(L-A1*kx0-A10*dertakx);

e1=-Q1*temp1'*lamda;

kx0=kx0+dertakx;

if norm(dertakx)<eps
    break;
end

end


V=L-A1*kx0-A10*dertakx; 

sigma0=sqrt(V'*Pl0*V/(size(A1,1)-7)); %%%% The square root of the posterior variance factor


e3=-Q31*temp1'*lamda; %%%% Residual vector of the source coordinates of non-common points


kx11=kx0(4);kx12=kx0(5);kx13=kx0(6);
kx21=kx0(7);kx22=kx0(8);kx23=kx0(9);
kx31=kx0(10);kx32=kx0(11);kx33=kx0(12);
Paramat=[kx11 kx12 kx13;kx21 kx22 kx23;kx31 kx32 kx33]; 

dalta_x0=kx0(1);dalta_y0=kx0(2);dalta_z0=kx0(3);
derta_xyz0=[dalta_x0;dalta_y0;dalta_z0]+[x2g;y2g;z2g]-Paramat*[x1g;y1g;z1g]; %%% recover the translation parameters from decentralized source to target system
dalta_x0=derta_xyz0(1);
dalta_y0=derta_xyz0(2);
dalta_z0=derta_xyz0(3);


xyz3_2=zeros(3*k2,1);


for i=1:k2
    temp1=[x3(i);y3(i);z3(i)];
    temp2=temp1-e3(3*i-2:3*i);
    xyz3_2(3*i-2:3*i)=Paramat*temp2+[dalta_x0;dalta_y0;dalta_z0];%%%%%% Transformed coordinates of non-common points obtained by CTLSP
  
end