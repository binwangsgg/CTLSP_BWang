clc;
clear;
close all;

load data_total; %%%% load the true spatial coordinates of all points in the source system, which were obtained through the transformation from BLH to XYZ.

k=size(data_total,1); %%%Դ����ϵ���ܵ���
xt1=zeros(k,1);yt1=zeros(k,1);zt1=zeros(k,1);

iselect=[];
for i=1:50
    xt1(i)=data_total(12+(i-1)*2,1);
    yt1(i)=data_total(12+(i-1)*2,2);
    zt1(i)=data_total(12+(i-1)*2,3);
    iselect=[iselect;12+(i-1)*2];
end

data_total(iselect,:)=[];

xt1(51:k)=data_total(:,1);
yt1(51:k)=data_total(:,2);
zt1(51:k)=data_total(:,3);



%%%% true values of the seven transformation parameters
dalta_x=-50;dalta_y=50;dalta_z=100;%%% Three translations
 K=1.001;alpha=1.0;beta=1.5;gamma=-0.5;%%%% Scale factor and rotation angles



%%% Constrcut the rotation matrix
M1=[1 0 0;0 cos(alpha) sin(alpha);0 -sin(alpha) cos(alpha)];
M2=[cos(beta) 0 -sin(beta);0 1 0;sin(beta) 0 cos(beta)];
M3=[cos(gamma) sin(gamma) 0;-sin(gamma) cos(gamma) 0;0 0 1];
M=M3*M2*M1;

Paramat0=K*M;


%%%% Obtain the true coordinates of the points in target system
xyzt2=zeros(3*k,1);
xt2=zeros(k,1);yt2=zeros(k,1);zt2=zeros(k,1);
for i=1:k
    temp1=[xt1(i);yt1(i);zt1(i)];
    xyzt2(3*i-2:3*i)=Paramat0*temp1+[dalta_x;dalta_y;dalta_z];
    xt2(i)=xyzt2(3*i-2);
    yt2(i)=xyzt2(3*i-1);
    zt2(i)=xyzt2(3*i);
end



x2=xt2(1:50);y2=yt2(1:50);z2=zt2(1:50); %%% The first fifty points are specified as common points

k1=size(x2,1); %%% The number of common points
k2=k-k1;   %%% The number of non-common points

load CTLSP_ex01_mt1_m2;  %%%%%  Load the arrays of the apriori standard deviations



%%%% Construct the correlation matrices Rt1 and R2, all of the correlations are set to 0.45 here
%%%% Rt1: the correlation matrix of observation errors for all points in source system
Rt1=eye(3*k);
for i=1:3*k
    for j=1:i
        if i~=j

            if (abs(i-j)<=2 && rem(max([i j]),3)==0) || (abs(i-j)==1 && rem(max([i j]),3)==2)
                    n01=0.45;
% %                      

            else
% %                              
              n01=0.45;   
            end
            Rt1(i,j)=n01;
        end
    end    
end
for i=1:3*k
  for j=i+1:3*k
      Rt1(i,j)=Rt1(j,i);
  end
end


%%%% R2: the correlation matrix of observation errors for common points in target system
R2=eye(3*k1);
for i=1:3*k1
    for j=1:i
        if i~=j

            if (abs(i-j)<=2 && rem(max([i j]),3)==0) || (abs(i-j)==1 && rem(max([i j]),3)==2)
                    n01=0.45;
% %                     

            else
                n01=0.45;         
% %                 
            end
            R2(i,j)=n01;
        end
    end    
end
for i=1:3*k1
  for j=i+1:3*k1
      R2(i,j)=R2(j,i);
  end
end

%%%% Construct the corresponding covariance matrices Dt1 and D2
Dt1=zeros(3*k,3*k); %%% Covariance matrix of the coordinates in source system
D2=zeros(3*k1,3*k1); %%% Covariance matrix of the coordinates in target system (only include common points)

for i=1:3*k
    for j=1:3*k
      Dt1(i,j)=mt1(i)*mt1(j)*Rt1(i,j);
    end
end

for i=1:3*k1
    for j=1:3*k1
      D2(i,j)=m2(i)*m2(j)*R2(i,j);
    end
end


%%%% Make preparations for generating the correlated random errors using cholesky decomposition
Cvt1=chol(Dt1);
Cv2=chol(D2);


xt10=xt1;yt10=yt1;zt10=zt1;
x20=x2;y20=y2;z20=z2;

Smx1=[];Smy1=[];Smz1=[];
Smx2=[];Smy2=[];Smz2=[];
Smx3=[];Smy3=[];Smz3=[];

Sn01=[];
Sn02=[];

xyzt1=zeros(3*k,1);
xyz2=zeros(3*k1,1);
SMp1=[];SMp2=[];


tc1=0;
tc2=0;
for simn0=1:1000 %%%% simn0: control the simulation times

%%%% Generate the random error vectors: rndt1 and rnd2
%%%% rndt1:the error vector for all points in source system
%%%% rnd2:the error vector for common points in target system
rndt1=normrnd(0,1,1,3*k);
rnd2=normrnd(0,1,1,3*k1);
rndt1=rndt1*Cvt1;
rnd2=rnd2*Cv2;


%%%%% Add the random errors to corresponding true coordinates
for i=1:k
    xyzt1(3*i-2)=xt10(i)+rndt1(3*i-2);
    xyzt1(3*i-1)=yt10(i)+rndt1(3*i-1);
    xyzt1(3*i)=zt10(i)+rndt1(3*i);
end
for i=1:k1

    xyz2(3*i-2)=x20(i)+rnd2(3*i-2);
    xyz2(3*i-1)=y20(i)+rnd2(3*i-1);
    xyz2(3*i)=z20(i)+rnd2(3*i);
end

sigma00=0.01; eps=1e-8;

[xyz3_1,n0,Dxyz3_1]=CTLS_02(xyzt1,xyz2,Dt1,D2,sigma00,eps); %%%% xyz3_1:  Transformed coordinates of non-common points obtained by CTLS

tic
[xyz3_2,n02]=CTLSP(xyzt1,xyz2,Dt1,D2,sigma00,eps);%%%%%%%  xyz3_2:  Transformed coordinates of non-common points obtained by CTLSP
c1=toc;
tc1=tc1+c1;

tic
[xyz3_02,n01]=GTLSP(xyzt1,xyz2,Dt1,D2,sigma00,eps);%%%%  xyz3_02:  Transformed coordinates of non-common points obtained by GTLSP
c2=toc;
tc2=tc2+c2;


[xyz3_4,n03,Dxyz3_2]=CTLSP_02(xyzt1,xyz2,Dt1,D2,sigma00,eps);%%%% The main difference with CTLSP.m is that CTLSP_02.m includes the part of precision assessment


Mp1=zeros(k2,1);
Mp2=zeros(k2,1);

for i=1:k2
    i1=3*i-2;
    i2=3*i-1;
    i3=3*i;
    Mp1(i)=sqrt(Dxyz3_1(i1,i1)+Dxyz3_1(i2,i2)+Dxyz3_1(i3,i3));
    Mp2(i)=sqrt(Dxyz3_2(i1,i1)+Dxyz3_2(i2,i2)+Dxyz3_2(i3,i3));
end

SMp1=[SMp1 Mp1];
SMp2=[SMp2 Mp2];





dx3_1=zeros(k2,1);dy3_1=zeros(k2,1);dz3_1=zeros(k2,1);
dx3_2=zeros(k2,1);dy3_2=zeros(k2,1);dz3_2=zeros(k2,1);
dx3_3=zeros(k2,1);dy3_3=zeros(k2,1);dz3_3=zeros(k2,1);


for i=1:(k2)
    
    dx3_1(i)=xyz3_1(3*i-2)-xt2(k1+i);
    dy3_1(i)=xyz3_1(3*i-1)-yt2(k1+i);
    dz3_1(i)=xyz3_1(3*i)-zt2(k1+i);
    
    dx3_2(i)=xyz3_2(3*i-2)-xt2(k1+i);
    dy3_2(i)=xyz3_2(3*i-1)-yt2(k1+i);
    dz3_2(i)=xyz3_2(3*i)-zt2(k1+i);
    
    dx3_3(i)=xyz3_02(3*i-2)-xt2(k1+i);
    dy3_3(i)=xyz3_02(3*i-1)-yt2(k1+i);
    dz3_3(i)=xyz3_02(3*i)-zt2(k1+i);
    
   
end

%%% RMSE for each direction 
mx1=norm(dx3_1)/sqrt(k2);
my1=norm(dy3_1)/sqrt(k2);
mz1=norm(dz3_1)/sqrt(k2);

mx2=norm(dx3_2)/sqrt(k2);
my2=norm(dy3_2)/sqrt(k2);
mz2=norm(dz3_2)/sqrt(k2);

mx3=norm(dx3_3)/sqrt(k2);
my3=norm(dy3_3)/sqrt(k2);
mz3=norm(dz3_3)/sqrt(k2);

Smx1=[Smx1;mx1];
Smx2=[Smx2;mx2];
Smx3=[Smx3;mx3];

Smy1=[Smy1;my1];
Smy2=[Smy2;my2];
Smy3=[Smy3;my3];

Smz1=[Smz1;mz1];
Smz2=[Smz2;mz2];
Smz3=[Smz3;mz3];

Sn01=[Sn01;n01];
Sn02=[Sn02;n02];

simn0;
    
end

%%% total CPU time of CTLSP
C_time_CTLSP=tc1

%%% total CPU time of GTLSP
C_time_GTLSP=tc2



compx=[Smx1 Smx2];
compy=[Smy1 Smy2];
compz=[Smz1 Smz2];

Sms1=sqrt(Smx1.^2+Smy1.^2+Smz1.^2); %%% Positional RMSE sequence obtained by CTLS
Sms2=sqrt(Smx2.^2+Smy2.^2+Smz2.^2);%%%Positional RMSE sequence obtained by CTLSP (The seamless one)
Sms3=sqrt(Smx3.^2+Smy3.^2+Smz3.^2);%%%Positional RMSE sequence obtained by GTLSP (The seamless one as well)



nn=1:1:simn0;

comps1=[Sms1 Sms2];
figure(1);
plot (nn,comps1)%%%%% Plot the sequences of positional RMSE obtained by CTLS and CTLSP
hold on

comps2=Sms2-Sms3;
figure(2);
plot (nn,comps2)%%%% Plot the difference of obtained positional RMSE between CTLSP and GTLSP
hold on

figure(3);
plot(nn,Sn01,'^g',nn,Sn02,'+r');%%%%  Plot the sequences of iterations (N) of CTLSP and GTLSP
hold on



% % tc2/tc1
nn1=1:1:k2;
P_std_CTLS=SMp1(:,1000);
P_std_CTLSP=SMp2(:,1000);
P_std_comp=[P_std_CTLS P_std_CTLSP];

figure(4)
plot(nn1,P_std_comp); %%%%%  Plot the positional std of the transformed coordinates for each check point (for the 1000th simulation)
hold on
   





